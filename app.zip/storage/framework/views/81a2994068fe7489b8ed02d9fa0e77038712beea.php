<?php $__env->startSection('main-content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\ELONGA\Projets\WEB\BACKEND\CIMR\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>