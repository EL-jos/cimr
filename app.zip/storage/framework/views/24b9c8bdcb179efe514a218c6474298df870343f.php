<?php $__env->startSection("heads"); ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">

    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/plugins/fontawesome-free/css/all.min.css")); ?>">

    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/plugins/datatables-responsive/css/responsive.bootstrap4.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/plugins/datatables-buttons/css/buttons.bootstrap4.min.css")); ?>">

    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/dist/css/adminlte.min2167.css?v=3.2.0")); ?>">
    <?php echo \Illuminate\View\Factory::parentPlaceholder('heads'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main-content"); ?>
    <div class="row">
        <div class="col-12">
            <?php if(session()->has('success')): ?>
                <div class="info-box">
                    <span class="info-box-icon bg-success"><i class="far fa-flag"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Valide</span>
                        <span class="info-box-number"><?php echo e(session()->get('success')); ?></span>
                    </div>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="info-box">
                    <span class="info-box-icon bg-danger"><i class="far fa-star"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Erreur</span>
                        <span class="info-box-number"><?php echo e(session()->get('error')); ?></span>
                    </div>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">DataTable with default features</h3>
                </div>
                <div class="card-body">
                    <div class="el-btns-controls">
                        <a href="<?php echo e(route('type.create')); ?>" class="btn btn-block btn-primary">Ajouter</a>
                        <a href="<?php echo e(route('type.trashed')); ?>" class="btn btn-block btn-secondary">Supprimées</a>
                        <a href="javascript:;" onclick="document.getElementById('el-clear-form').submit()" class="btn btn-block btn-danger">
                            Effacer
                            <form id="el-clear-form" action="<?php echo e(route('type.clear')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </a>
                    </div>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>titre</th>
                                <th>Nb. jours</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index  + 1); ?></td>
                                    <td><?php echo e(\Illuminate\Support\Str::upper($type->name)); ?></td>
                                    <td><?php echo e($type->nb_days); ?></td>
                                    <td>
                                        <div class="d-flex" style="gap: .5rem;">
                                            <?php if(!$type->trashed()): ?>
                                                <a href="<?php echo e(route('type.edit', $type)); ?>" class="btn bg-gradient-warning"><i class="fas fa-edit"></i></a>
                                                <button class="btn bg-gradient-danger" onclick="document.getElementById('el-form-<?php echo e($type->id); ?>').submit()">
                                                    <form id="el-form-<?php echo e($type->id); ?>" action="<?php echo e(route('type.destroy', $type)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            <?php else: ?>
                                                <button onclick="document.getElementById('el-restore-form-<?php echo e($type->id); ?>').submit()" class="btn bg-gradient-warning">
                                                    <form id="el-restore-form-<?php echo e($type->id); ?>" action="<?php echo e(route('type.restore', $type)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <i class="fas fa-trash-restore"></i>
                                                </button>
                                                <button class="btn bg-gradient-danger" onclick="document.getElementById('el-form-<?php echo e($type->id); ?>').submit()">
                                                    <form id="el-form-<?php echo e($type->id); ?>" action="<?php echo e(route('type.forceDelete', $type)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>titre</th>
                                <th>Nb. jours</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script src="<?php echo e(asset("assets/backend/plugins/jquery/jquery.min.js")); ?>"></script>

    <script src="<?php echo e(asset("assets/backend/plugins/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>

    <script src="<?php echo e(asset("assets/backend/plugins/datatables/jquery.dataTables.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-responsive/js/dataTables.responsive.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-responsive/js/responsive.bootstrap4.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-buttons/js/dataTables.buttons.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-buttons/js/buttons.bootstrap4.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/jszip/jszip.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/pdfmake/pdfmake.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/pdfmake/vfs_fonts.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-buttons/js/buttons.html5.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-buttons/js/buttons.print.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/plugins/datatables-buttons/js/buttons.colVis.min.js")); ?>"></script>

    <script src="<?php echo e(asset("assets/backend/dist/js/adminlte.min2167.js?v=3.2.0")); ?>"></script>

    

    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.pages.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\ELONGA\Projets\WEB\BACKEND\CIMR\resources\views/backend/resources/type/index.blade.php ENDPATH**/ ?>