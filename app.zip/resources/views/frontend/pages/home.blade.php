@extends('frontend.layouts.base')

@section('main-content')

@endsection
